from modelservicecontext import EModelContextStatus
from modelservicecontext import ERequestResponseDataFlag
from modelservicecontext import ERequestResponseDataMIME
from modelservicecontext import ModelServiceContext
from modeldatahandler import ModelDataHandler
import sys
import os
import shutil
import linecache

######################################################################################
# model program
import re
import jieba
import wordcloud
def createWC(language, filePath, imgPath, imgWidth=400, imgHeight=200, imgBgC="black"):
    f = open(filePath, encoding="utf-8")
    txt = f.read()
    f.close()
    rTxt = re.sub('[\{\}\[\]\"\":0-9_/-=&\? %,+\(\)]+', " ", txt)
    rTxt = re.sub('\s+', " ", rTxt)
    rStr = ""
    if language == "Chinese":
        ls = jieba.lcut(rTxt)
        rStr = "".join(ls)
    elif language == "English":
        rStr = rTxt
    else:
        print("incorrect input")
        return
    w = wordcloud.WordCloud(font_path="msyh", width=imgWidth, height=imgHeight, background_color=imgBgC)
    w.generate(rStr)
    w.to_file(imgPath)
#end
##########################################################################################
# encapsulation program
# Begin encapsulation
if len(sys.argv) < 3:
	exit()

ms = ModelServiceContext()
ms.onInitialize(sys.argv[1], sys.argv[2], sys.argv[3])
mdh = ModelDataHandler(ms)

print(ms.getMappingLibraryDirectory())

# Enter State
ms.onEnterState('run')

# Event
ms.onFireEvent('inputLanguageFile')

ms.onRequestData()

if ms.getRequestDataFlag() == ERequestResponseDataFlag.ERDF_OK:
	if ms.getRequestDataMIME() == ERequestResponseDataMIME.ERDM_RAW_FILE:
		lang_file_path = ms.getRequestDataBody()	
else:
	ms.onFinalize()

# Event
ms.onFireEvent('inputTextFile')

ms.onRequestData()

if ms.getRequestDataFlag() == ERequestResponseDataFlag.ERDF_OK:
	if ms.getRequestDataMIME() == ERequestResponseDataMIME.ERDM_RAW_FILE:
		file_path = ms.getRequestDataBody()
		
else:
	ms.onFinalize()

# Event
ms.onFireEvent('outputResult')

f = open(lang_file_path, "r")
lang = f.read().replace('\n', "")
f.close()

instance_dir = os.path.normpath(ms.getModelInstanceDirectory())
if not os.path.exists(instance_dir):
    os.makedirs(instance_dir)
result_path = os.path.normpath(instance_dir + "\\result.png") 
createWC(lang, file_path, result_path)

ms.setResponseDataFlag(ERequestResponseDataFlag.ERDF_OK)
ms.setResponseDataMIME(ERequestResponseDataMIME.ERDM_RAW_FILE)
ms.setResponseDataBody(result_path)

ms.onResponseData()
# Leave State
ms.onLeaveState()

ms.onFinalize()
